package com.books.bookzone;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class BuylendActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_rent_others);
    }
}
